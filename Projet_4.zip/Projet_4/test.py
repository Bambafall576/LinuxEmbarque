from sense_hat import SenseHat
sense=SenseHat()
#sense.show_message("bamba")

temp=sense.temperature
hum=sense.humidity
pres=sense.pressure
access=sense.accelerometer

temperature = print(round(temp,2))
humidite = print(round(hum,2))
pression = print(round(pres,2))
accelerometre = print(access)