Binôme: 
FALL Ousmane 
FALL Mouhamet Bamba

Nous avons réussi à envoyer les données des capteurs du Sense Hat via MQTT, du raspberry1 vers le raspberry2.
Ce dernier affiche ces données( température, pression et humidité) sur le dasboard de Node-red et calculer en même temps la qualité de l'air.
On a aussi réalisé un rappel vocal. Autrement dit, l'audio nous rappel si la qualité de l'air est bonne ou mauvaise.